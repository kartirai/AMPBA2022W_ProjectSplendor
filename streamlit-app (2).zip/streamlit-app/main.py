import os
import streamlit as st

# with open('style.css') as f:
    # st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

def main():
    """
    The main function for the Streamlit app.

    :return: None.
    """
    st.header("Marketing & Sales Application of AI using Chatbots (NLP) and Deep learning (ANN). Focus on customer experience application of AI")


    col1, col2, col3 = st.columns(3)

    with col1:
        option = st.selectbox('How would you like to be contacted?',('Email', 'Home phone', 'Mobile phone'))

    with col2:
        st.text_input("Enter a YouTube URL to summarize",key="v1")

    with col3:
        st.text_input("Enter a YouTube URL to summarize",key="v2")
   
        
    st.sidebar.image("logo.png", use_column_width=True)
    st.sidebar.markdown('# Hero Corporate Service Private Limited')
    st.sidebar.markdown("""<small>Hero Enterprise is the new avatar of Hero Corporate Service, which came into being in 2016, following a need to give a new direction to Brand Hero.
        Hero has a strong legacy of building world-class brands over 6 decades. 
        The Hero brand is associated with Hero Cycles, the world’s largest bicycle-making firm, and Hero Motocorp, the world’s largest two-wheeler firm. 
        Hero Enterprise. Ltd is chaired by Hero Enterprise Ltd Chairman Sunil Kant Munjal, 
        the youngest son of Hero Group Chairman BML Munjal, and has interests in insurance distribution, steelmaking, real estate, and corporate training.
        Hero Enterprise is also adding new dimensions to the Group’s legacy by venturing into new and exciting areas, 
        by drawing strength and inspiration from the entrepreneurial energies released by Hero in its formative years.</small>""", unsafe_allow_html=True)


    st.button('Predict')
        


if __name__ == '__main__':
    main()

