import os
import streamlit as st

# with open('style.css') as f:
    # st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

def main():
    """
    The main function for the Streamlit app.

    :return: None.
    """
    st.header("Marketing & Sales Application of AI using Chatbots (NLP) and Deep learning (ANN). Focus on customer experience application of AI")


    col1, col2, col3 = st.columns(3)

    # with col1:
    #     option = st.selectbox('How would you like to be contacted?',('Email', 'Home phone', 'Mobile phone'))

    # with col2:
    #     st.text_input("Input 1",key="v1")

    # with col3:
    #     st.text_input("Input 2",key="v2")
   
        
    st.sidebar.image("logo.png", use_column_width=True)
    st.sidebar.markdown('# Hero Corporate Service Private Limited')
    st.sidebar.markdown("""<small>Hero Enterprise is the new avatar of Hero Corporate Service, which came into being in 2016, following a need to give a new direction to Brand Hero.
        Hero has a strong legacy of building world-class brands over 6 decades. 
        The Hero brand is associated with Hero Cycles, the world’s largest bicycle-making firm, and Hero Motocorp, the world’s largest two-wheeler firm. 
        Hero Enterprise. Ltd is chaired by Hero Enterprise Ltd Chairman Sunil Kant Munjal, 
        the youngest son of Hero Group Chairman BML Munjal, and has interests in insurance distribution, steelmaking, real estate, and corporate training.
        Hero Enterprise is also adding new dimensions to the Group’s legacy by venturing into new and exciting areas, 
        by drawing strength and inspiration from the entrepreneurial energies released by Hero in its formative years.</small>""", unsafe_allow_html=True)


        
    # uploaded_file = st.file_uploader("Choose a file")

    st.button('Upload input file')

import streamlit as st
from github import Github
token = "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"
g = Github(token)
repo_name = "AMPBA2022W_ProjectSplendor"
repo = g.get_user().get_repo(repo_name)
# Streamlit UI
st.title("File Upload to GitHub")
file = st.file_uploader("Upload a file")

if file is not None:
    # Read the contents of the file
    file_contents = file.getvalue()
    
    # Upload the file to GitHub
    repo.create_file(file.name, "Upload from Streamlit", file_contents)
    st.success("File uploaded successfully!")



if __name__ == '__main__':
    main()

